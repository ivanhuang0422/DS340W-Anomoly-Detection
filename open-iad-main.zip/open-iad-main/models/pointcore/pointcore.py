import torch
import torch.nn as nn

__all__ = ['NetPointCore']

class NetPointCore(nn.Module):
    def __init__(self):
        super(NetPointCore).__init__()
        pass

    def forward(self, x):
        pass