from turtle import forward
import torch
import torch.nn as nn

__all__ = ['NeuralPoint']

class NeuralPoint(nn.Module):
    def __init__(self):
        super(NeuralPoint, self).__init__()
        pass

    def forward(self, x):
        pass
